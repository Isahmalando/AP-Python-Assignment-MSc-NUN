'''
a) Make a class called Restaurant. The __init__() method for Restaurant should store twoattributes: a restaurant_name and a cuisine_type.
Make a method called describe_restaurant() that prints these two pieces of information, 
and a method called open_restaurant() that prints a message indicating that the restaurant is open.
Make an instance called restaurant from your class. 
Print the two attributes individually, and then call both methods.
Create three different instances from the class, and call describe_restaurant() for each instance.
'''

class Restaurant:
    def __init__(self, restaurant_name, cuisine_type):
        self.restaurant_name = restaurant_name
        self.cuisine_type = cuisine_type

    def describe_restaurant(self):
        print(f"Restaurant Name: {self.restaurant_name}")
        print(f"Cuisine Type: {self.cuisine_type}")

    def open_restaurant(self):
        print(f"{self.restaurant_name} is now open!")

# Creating an instance called 'restaurant'
restaurant = Restaurant("The Great Restaurant", "Italian")

# Printing individual attributes
print(f"Restaurant Name: {restaurant.restaurant_name}")
print(f"Cuisine Type: {restaurant.cuisine_type}")

# Calling methods
restaurant.describe_restaurant()
restaurant.open_restaurant()

# Creating three different instances
restaurant1 = Restaurant("Food Haven", "Mexican")
restaurant2 = Restaurant("Sushi Delight", "Japanese")
restaurant3 = Restaurant("Burger Palace", "American")

# Calling describe_restaurant() for each instance
restaurant1.describe_restaurant()
restaurant2.describe_restaurant()
restaurant3.describe_restaurant()


'''
b) Add an attribute called number_served with a default value of 0. 
Create an instance called restaurant from this class. 
Print the number of customers the restaurant has served, and then change this value and print it again.
Add a method called set_number_served() that lets you set the number of customers that have been served. 
Call this method with a new number and print the value again.
Add a method called increment_number_served() that lets you increment the number of
customers who’ve been served. Call this method with any number you like that could represent 
how many customers were served in, say, a day of business.
'''

class Restaurant:
    def __init__(self, restaurant_name, cuisine_type):
        self.restaurant_name = restaurant_name
        self.cuisine_type = cuisine_type
        self.number_served = 0

    def describe_restaurant(self):
        print(f"Restaurant Name: {self.restaurant_name}")
        print(f"Cuisine Type: {self.cuisine_type}")

    def open_restaurant(self):
        print(f"{self.restaurant_name} is now open!")

    def set_number_served(self, number):
        self.number_served = number

    def increment_number_served(self, increment):
        self.number_served += increment

# Creating an instance called 'restaurant'
restaurant = Restaurant("The Great Restaurant", "Italian")

# Printing the number of customers served
print(f"Number of Customers Served: {restaurant.number_served}")

# Changing the value and printing it again
restaurant.number_served = 10
print(f"Number of Customers Served: {restaurant.number_served}")

# Using set_number_served() method
restaurant.set_number_served(20)
print(f"Number of Customers Served: {restaurant.number_served}")

# Using increment_number_served() method
restaurant.increment_number_served(5)
print(f"Number of Customers Served: {restaurant.number_served}")


'''
c) An ice cream stand is a specific kind of restaurant. Write a class called IceCreamStand that inherits from the Restaurant class.
Add an attribute called flavors that stores a list of ice cream flavors. Write a method that displays these flavors.
Create an instance of IceCreamStand, and call this method.

'''

class IceCreamStand(Restaurant):
    def __init__(self, restaurant_name, cuisine_type, flavors):
        super().__init__(restaurant_name, cuisine_type)
        self.flavors = flavors

    def display_flavors(self):
        print("Available Ice Cream Flavors:")
        for flavor in self.flavors:
            print(f"- {flavor}")

# Creating an instance of IceCreamStand
ice_cream_stand = IceCreamStand("Sweet Treats", "Dessert", ["Vanilla", "Chocolate", "Strawberry", "Mint Chip"])

# Calling the display_flavors() method
ice_cream_stand.display_flavors()