'''
a) Make a class called User. Create two attributes called first_name and last_name,
 and then create several other attributes that are typically stored in a user profile.
 Make a method called describe_user() that prints a summary of the user’s information.
 Make another method called greet_user() that prints a personalized greeting to the user.
 Create several instances representing different users, and call both methods for each user.
'''
 
class User:
    def __init__(self, first_name, last_name, age, email):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.email = email

    def describe_user(self):
        print(f"User Information:")
        print(f"Name: {self.first_name} {self.last_name}")
        print(f"Age: {self.age}")
        print(f"Email: {self.email}")

    def greet_user(self):
        print(f"Hello, {self.first_name}! Welcome back.")

# Creating instances representing different users
user1 = User("Hauwa", "Musa", 25, "hauwa.musa@example.com")
user2 = User("Jane", "Smith", 30, "jane.smith@example.com")
user3 = User("Ali", "Isah", 22, "ali.isah@example.com")

# Calling methods for each user
user1.describe_user()
user1.greet_user()

user2.describe_user()
user2.greet_user()

user3.describe_user()
user3.greet_user()



''' 
b) Add an attribute called login_attempts to your User class. Write a method called
increment_login_attempts() that increments the value of login_attempts by 1.
Write another method called reset_login_attempts() that resets the value of login_attempts to 0.
Make an instance of the User class and call increment_login_attempts() several times.
Print the value of login_attempts to make sure it was incremented properly, and then call reset_login_attempts().
Print login_attempts again to make sure it was reset to 0.
'''

class User:
    def __init__(self, first_name, last_name, age, email):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.email = email
        self.login_attempts = 0

    def describe_user(self):
        print(f"User Information:")
        print(f"Name: {self.first_name} {self.last_name}")
        print(f"Age: {self.age}")
        print(f"Email: {self.email}")

    def greet_user(self):
        print(f"Hello, {self.first_name}! Welcome back.")

    def increment_login_attempts(self):
        self.login_attempts += 1

    def reset_login_attempts(self):
        self.login_attempts = 0

# Creating an instance of the User class
user = User("John", "Doe", 25, "hauwa.musa@example.com")

# Incrementing login attempts and printing the value
user.increment_login_attempts()
user.increment_login_attempts()
user.increment_login_attempts()
print(f"Login Attempts: {user.login_attempts}")

# Resetting login attempts and printing the value
user.reset_login_attempts()
print(f"Login Attempts (after reset): {user.login_attempts}")




''' 
c) An administrator is a special kind of user. Write a class called Admin that inherits from the User class.
Add an attribute, privileges, that stores a list of strings like "can add post", "can delete post", "can ban user", and so on.
Write a method called show_privileges() that lists the administrator’s set of privileges.
Create an instance of Admin, and call your method.
Write a separate Privileges class. 
The class should have one attribute, privileges, that stores a list of strings as described above.
Move the show_privileges() method to this class. 
Make a Privileges instance as an attribute in the Admin class.
Create a new instance of Admin and use your method to show its privileges.
'''

class Admin(User):
    def __init__(self, first_name, last_name, age, email):
        super().__init__(first_name, last_name, age, email)
        self.privileges = Privileges()

    def show_privileges(self):
        self.privileges.show_privileges()

class Privileges:
    def __init__(self):
        self.privileges = ["can add post", "can delete post", "can ban user"]

    def show_privileges(self):
        print("Admin Privileges:")
        for privilege in self.privileges:
            print(f"- {privilege}")

# Creating an instance of Admin
admin = Admin("Admin", "User", 35, "admin@example.com")

# Calling show_privileges() method for the Admin instance
admin.show_privileges()